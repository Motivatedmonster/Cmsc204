// CourseDBStructure.java
package Assignment4;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.ListIterator;

public class CourseDBStructure implements CourseDBStructureInterface {
    private int hashtableSize;
    private ArrayList<LinkedList<CourseDBElement>> hashTable;

    public CourseDBStructure(String testing, int size) {
        this.hashtableSize = size;
        createTable();
    }
    public CourseDBStructure(int n) {
        this.hashtableSize = get4k((int)(n / 1.5));
        createTable();
    }

    private void createTable() {
        hashTable = new ArrayList<>(hashtableSize);
        for (int i = 0; i < hashtableSize; i++) {
            hashTable.add(null);
        }
    }

   
    @Override
    public CourseDBElement get(int crn) throws IOException {
        int index = Math.abs(Integer.toString(crn).hashCode()) % hashtableSize;
        LinkedList<CourseDBElement> bucket = hashTable.get(index);

        if (bucket == null || bucket.isEmpty()) {
            throw new IOException("Course not found");
        }

        for (CourseDBElement element : bucket) {
            if (element.getCRN() == crn) {
                return element;
            }
        }

        throw new IOException("Course not found");
    }
    @Override
    public void add(CourseDBElement element) {
        int index = Math.abs(Integer.toString(element.getCRN()).hashCode()) % hashtableSize;
        LinkedList<CourseDBElement> bucket = hashTable.get(index);

        if (bucket == null) {
            bucket = new LinkedList<>();
            hashTable.set(index, bucket);
        } else {
            for (ListIterator<CourseDBElement> it = bucket.listIterator(); it.hasNext(); ) {
                if (it.next().getCRN() == element.getCRN()) {
                    it.set(element);
                    return;
                }
            }
        }
        bucket.add(element);
    }
    

    @Override
    public ArrayList<String> showAll() {
        ArrayList<String> result = new ArrayList<>();

        for (int i = 0; i < hashTable.size(); i++) {
            LinkedList<CourseDBElement> bucket = hashTable.get(i);
            if (bucket == null || bucket.isEmpty()) continue;
            for (int j = 0; j < bucket.size(); j++) {
                CourseDBElement element = bucket.get(j);
                result.add(element.toString());
            }
        }

        return result;
    }

    @Override
    public int getTableSize() {
        return hashtableSize;
    }

    public ArrayList<CourseDBElement> getAllElements() {
        ArrayList<CourseDBElement> allElements = new ArrayList<>();
        for (LinkedList<CourseDBElement> bucket : hashTable) {
            if (bucket != null) {
                allElements.addAll(bucket);
            }
        }
        return allElements;
    }

    private int get4k(int number) {
    	int index = number + 1;
        while (!(isPrime(index) && (index % 4 == 3))) {
            index++;
        }
        return index;
    }

    private boolean isPrime(int n) {
        if (n < 2) return false;

        for (int i = 2; i * i <= n; i++) {
            if (n % i != 0) {
                continue;
            } else {
                return false;
            }
        }

        return true;
    }
}
