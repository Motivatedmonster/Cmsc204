package Assignment4;



import static org.junit.Assert.*;
import java.util.ArrayList;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CourseDBManager_STUDENT_Test {

    private CourseDBManagerInterface CDM;

    @Before
    public void setUp() throws Exception {
        CDM = new CourseDBManager();
    }

    @After
    public void tearDown() throws Exception {
        CDM = null;
    }

    @Test
    public void testAddAndGet() {
        CDM.add("ENGL101", 56907, 3, "ST101", "Words Wonderland");
        CourseDBElement cde = CDM.get(56907);
        assertEquals("ENGL101", cde.getID());
        assertEquals("ST101", cde.getRoomNum());
    }

    @Test
    public void testShowAllOrder() {
        CDM.add("CMSC216", 99999, 3, "ST200", "Rob Test");
        CDM.add("CMSC206", 55555, 4, "ST201", "Dagi Example");

        ArrayList<String> list = CDM.showAll();
        assertEquals(2, list.size());
        assertTrue(list.get(0).contains("CMSC206") || list.get(0).contains("CMSC216"));
        assertTrue(list.get(1).contains("CMSC206") || list.get(1).contains("CMSC216"));
    }

    @Test
    public void testGetNotFound() {
        assertNull(CDM.get(40404));
    }
}
