// CourseDBManager.java
package Assignment4;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;

public class CourseDBManager implements CourseDBManagerInterface {

    private CourseDBStructure CDS;

    public CourseDBManager() {
        CDS = new CourseDBStructure(100);
    }

    @Override
    public void add(String id, int crn, int credits, String roomNum, String instructor) {
        CourseDBElement element = new CourseDBElement(id, crn, credits, roomNum, instructor);
        CDS.add(element);
    }

    @Override
    public CourseDBElement get(int crn) {
        try {
            return CDS.get(crn);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public void readFile(File input) throws FileNotFoundException {
        Scanner scan = new Scanner(input);

        while (scan.hasNextLine()) {
        	String line = scan.nextLine().trim();
            Scanner currentScan = new Scanner(line);
            if (line.isEmpty()) continue;
            try {
                String id = currentScan.next();
                int crn = currentScan.nextInt();
                int credits = currentScan.nextInt();
                String room = currentScan.next();
                StringBuilder Instructorname = new StringBuilder();

                while (currentScan.hasNext()) {
                    Instructorname.append(currentScan.next()).append(" ");
                }
                String instructor = Instructorname.toString().trim();
                add(id, crn, credits, room, instructor);
            } catch (Exception e) {
            } finally {
                currentScan.close();
            }
        }

        scan.close();
    }

    @Override

    public ArrayList<String> showAll() {
        return CDS.showAll();

    }
}