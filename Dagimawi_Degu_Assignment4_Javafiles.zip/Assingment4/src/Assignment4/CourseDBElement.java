package Assignment4;

public class CourseDBElement implements Comparable<CourseDBElement>  {
    String courseID;
    int CRN;
    int Credits;
    String roomNumber;
    String instructorName;

    public CourseDBElement(String courseID, int crn, int credits, String roomNumber, String instructorName) {
        this.courseID = courseID;
        this.CRN = crn;
        this.Credits = credits;
        this.roomNumber = roomNumber;
        this.instructorName = instructorName;
    }

    public String getID() {
        return courseID;
    }

    public int getCRN() {
        return CRN;
    }

    public int getCredits() {
        return Credits;
    }

    public String getRoomNum() {
        return roomNumber;
    }

    public String getInstructorName() {
        return instructorName;
    }

    @Override
    public int compareTo(CourseDBElement second) {
        return Integer.compare(this.CRN, second.CRN);
    }

    @Override
    public int hashCode() {
        return Integer.toString(CRN).hashCode();
    }

    @Override
    public String toString() {
        return "\nCourse:" + courseID + " CRN:" + CRN + " Credits:" + Credits +  " Instructor:" + instructorName + " Room:" + roomNumber;
    }
} 

