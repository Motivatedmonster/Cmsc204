package Assignment1;

public class UnmatchedException extends Exception {

	public UnmatchedException(String string) {
		// TODO Auto-generated constructor stub
	}

}
