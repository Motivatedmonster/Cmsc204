package Assignment1;
import static org.junit.Assert.*;
import java.util.ArrayList;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
/**
* STUDENT tests for the methods of PasswordChecker
*/
public class PasswordCheckerTest_STUDENT {
   private ArrayList<String> testruns;
   @Before
   public void setUp() throws Exception {
       testruns = new ArrayList<>();
       testruns.add("Hello@123"); 
       testruns.add("AAAbb@123");  
       testruns.add("Aaabb@123");  
   }
   @After
   public void tearDown() throws Exception {
       testruns = null;
   }
   @Test
   public void testIsValidPasswordTooShort() {
       try {
           PasswordCheckerUtility.isValidPassword("Dagi");
           fail("Expected LengthException");
       } catch (LengthException e) {
           assertEquals("The password must be at least 6 characters long", e.getMessage());
       } catch (Exception e) {
           fail("Wrong exception thrown");
       }
   }
   @Test
   public void testIsValidPasswordNoUpperAlpha() {
       try {
           PasswordCheckerUtility.isValidPassword("hello@123");
           fail("Expected NoUpperAlphaException");
       } catch (NoUpperAlphaException e) {
           assertEquals("The password must contain at least one uppercase alphabetic character", e.getMessage());
       } catch (Exception e) {
           fail("Wrong exception thrown");
       }
   }
   @Test
   public void testIsValidPasswordNoLowerAlpha() {
       try {
           PasswordCheckerUtility.isValidPassword("HELLO@123");
           fail("Expected NoLowerAlphaException");
       } catch (NoLowerAlphaException e) {
           assertEquals("The password must contain at least one lowercase alphabetic character", e.getMessage());
       } catch (Exception e) {
           fail("Wrong exception thrown");
       }
   }
   @Test
   public void testIsWeakPassword() {
       assertTrue(PasswordCheckerUtility.isWeakPassword("Abc@12"));
   }
   @Test
   public void testIsValidPasswordInvalidSequence() {
       try {
           PasswordCheckerUtility.isValidPassword("AAAbb@123");
           fail("Expected InvalidSequenceException");
       } catch (InvalidSequenceException e) {
           assertEquals("The password cannot contain more than two of the same character in sequence", e.getMessage());
       } catch (Exception e) {
           fail("Wrong exception thrown");
       }
   }
   @Test
   public void testIsValidPasswordNoDigit() {
       try {
           PasswordCheckerUtility.isValidPassword("Hello@World"); 
           fail("Expected NoDigitException");
       } catch (NoDigitException e) {
           assertEquals("The password must contain at least one digit", e.getMessage());
       } catch (Exception e) {
           fail("Wrong exception thrown");
       }
   }
   @Test
   public void testIsValidPasswordSuccessful() {
       try {
           assertTrue(PasswordCheckerUtility.isValidPassword("Hello123$"));
           assertTrue(PasswordCheckerUtility.isValidPassword("Upgra12$")); 
       } catch (Exception e) {
           fail("Valid Password");
       }
   }
   @Test
   public void testInvalidPasswords() {
       ArrayList<String> testPasswords = new ArrayList<>();
       testPasswords.add("123456");  
       testPasswords.add("abcdef");   
       
       ArrayList<String> invalidPasswords = PasswordCheckerUtility.getInvalidPasswords(testPasswords);
      
       assertEquals(2, invalidPasswords.size());
      
       assertTrue(invalidPasswords.get(0).contains("The password must contain at least one uppercase alphabetic character"));
       assertTrue(invalidPasswords.get(1).contains("The password must contain at least one uppercase alphabetic character"));
       
   }
}
