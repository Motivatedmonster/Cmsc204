package Assignment1;
import java.util.ArrayList;
public class PasswordCheckerUtility {
  public static boolean upperCase(String word) {
      for (char i : word.toCharArray()) {  
          if (Character.isUpperCase(i)) {
              return true;
          }
      }
      return false;
  }
  public static boolean lowerCase(String word) {
      for (char i : word.toCharArray()) {  
          if (Character.isLowerCase(i)) {
              return true;
          }
      }
      return false;
  }
  public static boolean hasDigit(String word) {
      for (char i : word.toCharArray()) {  
          if (Character.isDigit(i)) {
              return true;
          }
      }
      return false;
  }
  public static boolean specialCharacter(String word) {
      for (char i : word.toCharArray()) {  
          if (!Character.isLetterOrDigit(i)) {
              return true;
          }
      }
      return false;
  }
  public static boolean invalidSequence(String password) {
      for (int i = 0; i < password.length() - 1; i++) {
          if (password.charAt(i) == password.charAt(i + 1) && password.charAt(i) == password.charAt(i + 2)) {
              return true;
          }
      }
      return false;
  }
  public static boolean isWeakPassword(String password) throws WeakPasswordException {
	    if (password.length() >= 6 && password.length() <= 9) {
	        throw new WeakPasswordException();  
	    }
	    return false; 
	}
  public static ArrayList<String> getInvalidPasswords(ArrayList<String> passwords) {
      ArrayList<String> invalidPasswords = new ArrayList<>();
      for (String password : passwords) {
          try {
              isValidPassword(password);  
          } catch (Exception e) {
              invalidPasswords.add(password + " " + e.getMessage()); 
          }
      }
      return invalidPasswords;
  }
  public static boolean isValidPassword(String password) throws Exception {
      if (password.length() < 6) {
          throw new LengthException();
      }
      if (!upperCase(password)) {
          throw new NoUpperAlphaException();
      }
      if (!lowerCase(password)) {
          throw new NoLowerAlphaException();
      }
      if (!hasDigit(password)) {
          throw new NoDigitException();
      }
      if (!specialCharacter(password)) {
          throw new NoSpecialCharacterException();
      }
      if (invalidSequence(password)) {
          throw new InvalidSequenceException();
      }
      return true;
  }
}